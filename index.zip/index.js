'use strict'

exports.handler = async function (event, context) {
   console.log('testing');
   return 'something';
} 
